<?PHP
class PasswordRandow  {
public function __construct(){
}
function exe($data){
eTrace(">>PasswordRandow");
global $_;
return "**3**";
}
}
?>