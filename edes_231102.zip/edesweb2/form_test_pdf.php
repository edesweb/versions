<?PHP
$dim = array(
array("{uno}" , "111"),
array("{dos}" , "222"),
array("{tres}", "333")
);
$dim1 = array(
array("{uno}" , "a111"),
array("{dos}" , "a222"),
array("{tres}", "a333")
);
$dim2 = array(
array("{uno}" , "b111"),
array("{dos}" , "b222"),
array("{tres}", "b333")
);
eFormPrint(2, $dim);
?>
