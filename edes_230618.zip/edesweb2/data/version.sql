210610: alter table gs_storage modify text_es varchar(9000)
210610: alter table gs_conexion DROP COLUMN sesion
220822: alter table gs_user add pass_error int(5)
220822: alter table gs_user add pass_error_cdi datetime NULL
220822: alter table gs_conexion modify id varchar(65) not null
220822: create table gs_serial( cd_gs_conexion int(10) unsigned not null, pk int(10) unsigned not null, UNIQUE gs_serial(cd_gs_conexion) ) ENGINE=InnoDB DEFAULT CHARSET=latin1
220822: DROP TABLE IF EXISTS gs_context
220822: create table gs_context ( cd_gs_conexion int(10) unsigned NOT NULL, context int(10) unsigned NOT NULL, type varchar(5) NOT NULL, script varchar(160) NOT NULL, data varchar(255) NULL, KEY gs_context (cd_gs_conexion, context, type, script) )  ENGINE=InnoDB DEFAULT CHARSET=latin1
221128: alter table gs_context modify data varchar(900)
