<script type="text/javascript">
location.replace('edes.php?FmR:$a/d/usu_clave&_SEEK&cd_gs_user=<?=S::$_User?>');
</script>
