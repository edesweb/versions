<?PHP
$type	= $_POST['type'] ?: "";
$field	= $_POST['field'];
$source	= $_POST['source'];
$value	= $_POST['value'];
$serial	= $_POST['serial'];
$pk		= $_POST['pk'];
$exe	= $_POST['exe'];
$dim = SYS::getLabel($source, "DB, DBTable, DBSerial, UploadFile, AddCode", true);
$DBTable = $dim["DBTable"][0];
$DBSerial = $dim["DBSerial"][0];
$sql = "update {$DBTable} set {$field}='{$value}' where {$DBSerial}='{$serial}'";
S::qQuery($sql);
for($i=0; $i<count($dim["UploadFile"]); $i++){
if( $dim["UploadFile"][$i][0]!=$field ){
continue;
}
$nameFile = eScript($dim["UploadFile"][$i][1])."/";
if( !empty($dim["UploadFile"][$i][6]) ){
$nameFile .= $dim["UploadFile"][$i][6];
}
$nameFile .= "{$serial}.".strtolower(eFileType($value));
rename($oFile, $nameFile);
}
if( strlen($exe)>5 ){
$exe = eScript($exe);
exec("php {$exe} {$DBTable} {$field} {$DBSerial} {$serial} > /dev/null &", $lines);
}
?>
