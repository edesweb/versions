<?PHP
define('_ERROR_REPORTING', 5);
define('_TRACK_ERRORS'	 , false);
define('SETUP'  , '.' );
define('DIREDES', __DIR__.'/');
$xDownloadPath	 = $argv[1];
$xDownloadDelete = $argv[2];
$nDaily			 = $argv[3]*1;
include(DIREDES.'del_fichero.inc');
include("../_datos/config/setup.class.php");
$daySess = (SETUP::$System['SessionMaxLife']/86400)*2;
BorraFicheros('../_d_'		,  1, 'dvl');
BorraFicheros('../_tmp'		, 15);
BorraFicheros('../_tmp/cch'	,  1);
BorraFicheros('../_tmp/exc'	,  7);
BorraFicheros('../_tmp/pdf'	,  1);
BorraFicheros('../_tmp/php'	,  1);
BorraFicheros('../_tmp/zip'	,  7);
BorraFicheros('../_tmp/lcl'	,  2);
BorraFicheros('../_tmp/sess', $daySess);
BorraFicheros('../_tmp/err'	, 90);
BorraFicheros('../_tmp/log' ,  1);
BorraFicheros($xDownloadPath, $xDownloadDelete);
if( !empty($xDownloadPath) && substr_count($xDownloadPath, '/_tmp/exp')==0 ){
BorraFicheros('../_tmp/exp', 7);
}
BorraFicheros('../_bak_/_daily', $nDaily);
?>
